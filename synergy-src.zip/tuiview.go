// GOMNI TUI v3 — отрисовка: лэйаут, панели, пикеры, тосты, точка входа.

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ---------- мини-зоны мыши (без bubblezone) ----------
type zoneMgr struct {
	ids map[string][4]int
}

func newZoneMgr() *zoneMgr                  { return &zoneMgr{ids: map[string][4]int{}} }
func (z *zoneMgr) Mark(id, s string) string { return s }
func (z *zoneMgr) reset()                   { z.ids = map[string][4]int{} }
func (z *zoneMgr) set(id string, x0, y0, x1, y1 int) {
	if x1 < x0 {
		x1 = x0
	}
	z.ids[id] = [4]int{x0, y0, x1, y1}
}
func (z *zoneMgr) Register(id string, x0, y0, x1, y1 int) { z.ids[id] = [4]int{x0, y0, x1, y1} }
func (z *zoneMgr) Get(id string) *zoneMgr                 { return z }
func (z *zoneMgr) InBounds(msg tea.MouseMsg) bool         { return false }

// полноценный hit-test: регистрируем прямоугольники при отрисовке
func (z *zoneMgr) hit(id string, msg tea.MouseMsg) bool {
	r, ok := z.ids[id]
	if !ok {
		return false
	}
	return msg.X >= r[0] && msg.X <= r[2] && msg.Y >= r[1] && msg.Y <= r[3]
}
func (z *zoneMgr) Close() {}

func (m tuiModel) View() string {
	m.bz.reset()
	if m.width < 60 {
		return m.miniView()
	}
	top := m.renderTop()
	body := m.renderBody()
	out := lipgloss.JoinVertical(lipgloss.Top, top, body)
	if toasts := m.renderToasts(); toasts != "" {
		out += "\n" + toasts
	}
	return out
}

func (m tuiModel) miniView() string {
	var b strings.Builder
	b.WriteString(lipgloss.NewStyle().Bold(true).Foreground(clAccent).Render("GOMNI ") +
		lipgloss.NewStyle().Foreground(clMuted).Render(providerShort(m.provider)+" | "+shortModel(m.model)))
	b.WriteString("\n" + strings.Repeat("─", m.width))
	s := m.sessions[m.cur]
	s.mu.Lock()
	ls := make([]tline, len(s.lines))
	copy(ls, s.lines)
	s.mu.Unlock()
	for _, l := range ls[len(ls)-8:] {
		b.WriteString(trunc(renderLine(l), m.width) + "\n")
	}
	b.WriteString(m.input.View())
	return b.String()
}

func (m *tuiModel) layout() {
	w := m.width - 2
	mainW := w
	if (m.sidebar || m.sidebarAnim > 0) && m.width >= 96 {
		sbW := 4 + m.sidebarAnim*3 + m.sidebarAnim/4 // синхронно с renderSidebar
		if sbW > 30 {
			sbW = 30
		}
		mainW = w - sbW
	}
	s := m.sessions[m.cur]
	s.mu.Lock()
	empty := len(s.lines) == 0 || (len(s.lines) == 1 && s.lines[0].kind == "info")
	s.mu.Unlock()
	if empty {
		m.input.width = m.inputWidthFor(true) - 6
	} else {
		m.input.width = mainW - 6
	}
	m.vp.Width = mainW
	// высота транскрипта = экран минус топ (2), статус-бар (1), чип (1), редактор (динамически)
	edH := m.input.heightInLines()
	m.vp.Height = m.height - 4 - edH
	if m.vp.Height < 3 {
		m.vp.Height = 3
	}
	m.refreshTranscript()
}

// ---------- верхняя панель с кнопками (с hit-зонами для мыши) ----------
func (m tuiModel) renderTop() string {
	z := m.bz
	// кнопки-пилюли: крупнее (padding 0,2) со скруглёнными краями ◜◝
	btn := func(label string) string {
		return lipgloss.NewStyle().Foreground(clSel).Render("") +
			lipgloss.NewStyle().Padding(0, 2).Foreground(clFG).Background(clSel).Render(label) +
			lipgloss.NewStyle().Foreground(clSel).Render("")
	}
	btnAcc := func(label string) string {
		return lipgloss.NewStyle().Foreground(clAccent).Render("") +
			lipgloss.NewStyle().Padding(0, 2).Bold(true).Foreground(clBG).Background(clAccent).Render(label) +
			lipgloss.NewStyle().Foreground(clAccent).Render("")
	}

	// левый угол: ☰ панель чатов + бренд
	leftBtn := btn("☰")
	z.set("btn_side", 0, 0, visibleWidth(leftBtn)-1, 0)
	left := leftBtn + " " + lipgloss.NewStyle().Bold(true).Foreground(clAccent).Render("SYNERGY") +
		" " + lipgloss.NewStyle().Foreground(clMuted).Render("["+providerShort(m.provider)+"]")

	// правый угол: модель, модели, настройки
	chipSeg := lipgloss.NewStyle().Padding(0, 1).Foreground(clCyan).
		Render(shortModel(m.model) + " ◎" + strings.Repeat("●", m.reasoning+1))
	modelsBtn := btn("модели")
	cfgBtn := btn("⚙")
	right := chipSeg + " " + modelsBtn + " " + cfgBtn

	// регистрация зон правого угла: считаем от правого края
	rx := m.width - visibleWidth(right)
	z.set("chip", rx, 0, rx+visibleWidth(chipSeg)-1, 0)
	rx += visibleWidth(chipSeg) + 1
	z.set("btn_models", rx, 0, rx+visibleWidth(modelsBtn)-1, 0)
	rx += visibleWidth(modelsBtn) + 1
	z.set("btn_cfg", rx, 0, rx+visibleWidth(cfgBtn)-1, 0)

	// "+ чат" — акцентная кнопка после бренда слева
	newBtn := btnAcc("+")
	nx := visibleWidth(left) + 1
	z.set("btn_new", nx, 0, nx+visibleWidth(newBtn)-1, 0)
	left = left + " " + newBtn

	gap := m.width - visibleWidth(left) - visibleWidth(right)
	if gap < 1 {
		gap = 1
	}
	line := left + strings.Repeat(" ", gap) + right
	return lipgloss.NewStyle().Width(m.width).MaxHeight(1).Render(line)
}

// ---------- основное тело ----------
func (m tuiModel) renderBody() string {
	if m.settings {
		return m.renderSettings()
	}
	if m.picker {
		return m.renderPicker()
	}
	mainCol := m.renderMainCol()
	if (m.sidebar || m.sidebarAnim > 0) && m.width >= 96 {
		side := m.renderSidebar()
		if m.sidebarRight {
			return lipgloss.JoinHorizontal(lipgloss.Top, mainCol, side)
		}
		return lipgloss.JoinHorizontal(lipgloss.Top, side, mainCol)
	}
	return mainCol
}

func (m tuiModel) renderMainCol() string {
	s := m.sessions[m.cur]
	s.mu.Lock()
	empty := len(s.lines) == 0 || (len(s.lines) == 1 && s.lines[0].kind == "info")
	s.mu.Unlock()

	var area string
	if empty {
		// Референс Frame 2: приветствие по центру, а под ним — крупный инпут тоже по центру.
		greet := m.renderGreeting()
		boxW := m.inputWidthFor(empty)
		box := lipgloss.NewStyle().
			Border(lipgloss.RoundedBorder()).
			BorderForeground(clAccent).
			Padding(1, 2).
			Width(boxW).
			Render(m.input.View())
		centeredBox := lipgloss.NewStyle().Width(m.mainColWidth()).Align(lipgloss.Center).Render(box)
		chips := lipgloss.NewStyle().Width(m.mainColWidth()).Align(lipgloss.Center).
			Render(m.renderInputChip())
		return lipgloss.JoinVertical(lipgloss.Top, greet, centeredBox, "", chips)
	}
	area = m.vp.View()
	inputBox := lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(clBorder).
		Padding(0, 1).
		Render(m.input.View())
	inputArea := lipgloss.JoinVertical(lipgloss.Top, m.renderStatusBar(), m.renderInputChip(), inputBox)
	if m.compl.visible && len(m.compl.items) > 0 {
		var rows []string
		for i, c := range m.compl.items {
			if i > 7 {
				rows = append(rows, lipgloss.NewStyle().Foreground(clMuted).Render(fmt.Sprintf("  +%d ещё", len(m.compl.items)-8)))
				break
			}
			if i == m.compl.sel {
				rows = append(rows, lipgloss.NewStyle().Foreground(clBG).Background(clAccent).Render(" "+c+" "))
			} else {
				rows = append(rows, lipgloss.NewStyle().Foreground(clMuted).Render(" "+c))
			}
		}
		compBox := lipgloss.NewStyle().
			Border(lipgloss.RoundedBorder()).
			BorderForeground(clAccent).
			Padding(0, 1).
			Render(strings.Join(rows, "\n"))
		inputArea = lipgloss.JoinVertical(lipgloss.Top, compBox, inputArea)
	}
	if todos := m.renderTodos(); todos != "" {
		inputArea = lipgloss.JoinVertical(lipgloss.Top, todos, inputArea)
	}
	return lipgloss.JoinVertical(lipgloss.Top, area, inputArea)
}

func (m tuiModel) renderInputChip() string {
	chip := fmt.Sprintf("%s | %s | размышления: %s",
		providerShort(m.provider),
		shortModel(m.model),
		[]string{"обычные", "глубокие", "максимальные"}[m.reasoning])
	return lipgloss.NewStyle().Foreground(clMuted).Render("    " + chip)
}

func shortModel(s string) string {
	if i := strings.LastIndex(s, "/"); i >= 0 {
		s = s[i+1:]
	}
	if len(s) > 22 {
		s = s[:22] + "…"
	}
	return s
}

// ---------- приветствие в центре ----------
func (m tuiModel) renderGreeting() string {
	// центр — чистый текст без рамок; единственная рамка со скруглением — у поля ввода
	rows := []string{
		lipgloss.NewStyle().Bold(true).Foreground(clAccent).Render("S Y N E R G Y"),
		"",
		lipgloss.NewStyle().Foreground(clFG).Render(T("greeting.sub")),
	}
	// список запущенных агентов: имя чата + статус готово/в процессе (как «Tasks» на референсе)
	if agents := m.renderAgentsList(); agents != "" {
		rows = append(rows, "", agents)
	}
	rows = append(rows, "",
		lipgloss.NewStyle().Foreground(clMuted).Render(T("greeting.hint1")),
		lipgloss.NewStyle().Foreground(clMuted).Render(T("greeting.hint2")),
	)
	inner := strings.Join(rows, "\n")
	centered := lipgloss.NewStyle().Width(m.width - 2).Align(lipgloss.Center).Render(inner)
	return lipgloss.NewStyle().
		Width(m.width-2).
		Height(m.height-8).
		Align(lipgloss.Center, lipgloss.Center).
		Render(centered)
}

// ---------- правая панель: чаты, сгруппированные по рабочим папкам ----------
func (m tuiModel) renderSidebar() string {
	grouped := map[string][]int{}
	var dirs []string
	for i, s := range m.sessions {
		if _, ok := grouped[s.workdir]; !ok {
			dirs = append(dirs, s.workdir)
		}
		grouped[s.workdir] = append(grouped[s.workdir], i)
	}
	sortStrs(dirs)

	sx0, sx1 := m.width-31, m.width-3
	y := 2 // строка под верхней панелью + рамка

	var b strings.Builder
	b.WriteString(lipgloss.NewStyle().Bold(true).Foreground(clBlue).Render(T("chats") + "\n"))
	for _, d := range dirs {
		short := d
		if short == "" {
			short = "."
		}
		b.WriteString(lipgloss.NewStyle().Foreground(clMuted).Render("  📁 "+trunc(filepath.Base(short), 24)) + "\n")
		y++
		for _, i := range grouped[d] {
			s := m.sessions[i]
			mark := "  "
			if i == m.cur {
				mark = "▶"
			}
			status := ""
			if s.running {
				status = " …"
			}
			label := fmt.Sprintf("%s %s%s", mark, s.name, status)
			var item string
			if i == m.cur {
				item = lipgloss.NewStyle().Padding(0, 1).Foreground(clBG).Background(clAccent).Render(label)
			} else {
				item = lipgloss.NewStyle().Padding(0, 1).Foreground(clFG).Render(label)
			}
			m.bz.set(fmt.Sprintf("sess:%d", i), sx0, y, sx1, y)
			b.WriteString(m.bz.Mark(fmt.Sprintf("sess:%d", i), item) + "\n")
			y++
		}
	}
	b.WriteString("\n" + lipgloss.NewStyle().Foreground(clMuted).Render(T("chats.hint")+"\n"))
	w := 4 + m.sidebarAnim*3 + m.sidebarAnim/4 // 0→4, 8→30: плавное выезжание
	if w > 30 {
		w = 30
	}
	return lipgloss.NewStyle().
		Width(w).
		MaxWidth(w).
		Height(m.height - 3).
		Border(lipgloss.RoundedBorder()).
		BorderForeground(clSel).
		Render(b.String())
}

func sortStrs(xs []string) {
	for i := 1; i < len(xs); i++ {
		for j := i; j > 0 && xs[j] < xs[j-1]; j-- {
			xs[j], xs[j-1] = xs[j-1], xs[j]
		}
	}
}

// ---------- окно параметров ----------
func (m tuiModel) renderSettings() string {
	provLine := "  Провайдер:  "
	for _, p := range providerDefs {
		mark := " "
		if p.Name == m.provider {
			mark = "▶"
		}
		style := lipgloss.NewStyle().Foreground(clMuted)
		if p.Name == m.provider {
			style = lipgloss.NewStyle().Bold(true).Foreground(clCyan)
		}
		provLine += style.Render(fmt.Sprintf("%s%s", mark, p.Name)) + "   "
	}
	reason := []struct {
		l string
		d string
	}{{"обычные", "◎"}, {"глубокие", "◎◎"}, {"максимальные", "◎◎◎"}}
	var rLine strings.Builder
	rLine.WriteString("  Размышления:  ")
	for i, r := range reason {
		style := lipgloss.NewStyle().Foreground(clMuted)
		if i == m.reasoning {
			style = lipgloss.NewStyle().Bold(true).Foreground(clYellow)
		}
		rLine.WriteString(style.Render(fmt.Sprintf("%s %s", r.d, r.l)) + "   ")
	}
	onoff := func(b bool) string {
		if b {
			return lipgloss.NewStyle().Foreground(clGreen).Render(T("on"))
		}
		return lipgloss.NewStyle().Foreground(clRed).Render(T("off"))
	}
	side := T("left")
	if m.sidebarRight {
		side = T("right")
	}
	enterMode := T("enter.send")
	if m.ctrlEnterNewline {
		enterMode = T("enter.newline")
	}
	lines := []string{
		lipgloss.NewStyle().Bold(true).Foreground(clAccent).Render(T("settings")),
		"",
		provLine,
		T("settings.model") + lipgloss.NewStyle().Foreground(clCyan).Render(m.model) + lipgloss.NewStyle().Foreground(clMuted).Render(T("settings.model.hint")),
		rLine.String(),
		"",
		T("settings.key") + lipgloss.NewStyle().Foreground(clCyan).Render(maskKey(m.providerKeyStatus())) + lipgloss.NewStyle().Foreground(clMuted).Render("  (K — ввести)"),
		T("settings.lang") + lipgloss.NewStyle().Foreground(clCyan).Render(uiLang) + lipgloss.NewStyle().Foreground(clMuted).Render("  (L)"),
		T("settings.failover") + onoff(m.failoverOn) + lipgloss.NewStyle().Foreground(clMuted).Render(" → "+orDefault(m.failoverTarget, "auto")+"  (F)"),
		T("settings.sidebar") + lipgloss.NewStyle().Foreground(clCyan).Render(side) + lipgloss.NewStyle().Foreground(clMuted).Render("  (B)"),
		T("settings.enter") + lipgloss.NewStyle().Foreground(clCyan).Render(enterMode) + lipgloss.NewStyle().Foreground(clMuted).Render("  (E)"),
		"",
		T("settings.notify") + lipgloss.NewStyle().Foreground(clMuted).Render(notifyInfo()),
		T("settings.workdir") + lipgloss.NewStyle().Foreground(clMuted).Render(m.sessions[m.cur].workdir),
		"",
		lipgloss.NewStyle().Foreground(clMuted).Render(T("settings.keys")),
	}
	if m.provStep > 0 {
		prompt := []string{"", "имя провайдера (напр. Groq):", "base URL (напр. https://api.groq.com/openai/v1):", "API-ключ (Enter — пропустить):"}[m.provStep]
		lines = []string{
			lipgloss.NewStyle().Bold(true).Foreground(clAccent).Render("  ＋ Свой провайдер — шаг " + fmt.Sprint(m.provStep) + "/3"),
			"",
			"  " + lipgloss.NewStyle().Foreground(clMuted).Render(prompt),
			"",
			lipgloss.NewStyle().Border(lipgloss.RoundedBorder()).BorderForeground(clAccent).Padding(0, 1).
				Render(lipgloss.NewStyle().Foreground(clFG).Render(m.provBuf + "▌")),
			"",
			lipgloss.NewStyle().Foreground(clMuted).Render("  Enter — дальше • Esc — отмена"),
		}
		if m.provName != "" {
			lines[2] = "  " + lipgloss.NewStyle().Foreground(clCyan).Render(m.provName) + " " + lipgloss.NewStyle().Foreground(clMuted).Render(prompt)
		}
	} else if m.keyEdit {
		stars := strings.Repeat("•", len([]rune(m.keyBuf)))
		lines = []string{
			lipgloss.NewStyle().Bold(true).Foreground(clAccent).Render(T("settings.key.edit")),
			"",
			"  " + lipgloss.NewStyle().Foreground(clCyan).Render(m.provider),
			"",
			lipgloss.NewStyle().Border(lipgloss.RoundedBorder()).BorderForeground(clAccent).Padding(0, 1).
				Render(lipgloss.NewStyle().Foreground(clFG).Render(stars + "▌")),
			"",
			lipgloss.NewStyle().Foreground(clMuted).Render(T("settings.key.hint")),
		}
	}
	box := lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(clAccent).
		Padding(1, 3).
		Render(strings.Join(lines, "\n"))
	return lipgloss.NewStyle().
		Width(m.width-2).
		Height(m.height-3).
		Align(lipgloss.Center, lipgloss.Center).
		Render(box)
}

func notifyInfo() string {
	if c := os.Getenv("GOMNI_NOTIFY_CMD"); c != "" {
		return "cmd: " + trunc(c, 30)
	}
	if haveTermuxNotify() {
		return "termux-notification ✓"
	}
	return "нет (GOMNI_NOTIFY_CMD или termux-notification)"
}

// ---------- пикер (модели/провайдер/чаты/справка) ----------
func (m tuiModel) renderPicker() string {
	var lines []string
	lines = append(lines, lipgloss.NewStyle().Bold(true).Foreground(clBlue).Render("  "+m.pickerTitle))
	lines = append(lines, "")
	start := 0
	if len(m.pickerItems) > m.height-8 {
		start = m.pickerSel - (m.height-8)/2
		if start < 0 {
			start = 0
		}
		end := start + m.height - 8
		if end > len(m.pickerItems) {
			end = len(m.pickerItems)
		}
		if start > end-(m.height-8) {
			start = end - (m.height - 8)
			if start < 0 {
				start = 0
			}
		}
	}
	show := m.pickerItems[start:]
	if len(show) > m.height-8 {
		show = show[:m.height-8]
	}
	for idx := start; idx < start+len(show); idx++ {
		it := show[idx-start]
		style := lipgloss.NewStyle().Foreground(clFG).Padding(0, 1)
		if idx == m.pickerSel {
			style = lipgloss.NewStyle().Bold(true).Foreground(clBG).Background(clAccent).Padding(0, 1)
		}
		lines = append(lines, style.Render(trunc(it, m.width-12)))
	}
	lines = append(lines, "")
	lines = append(lines, lipgloss.NewStyle().Foreground(clMuted).Render("  ↑/↓ — выбор • Enter — ок • Esc — отмена"))
	box := lipgloss.NewStyle().
		Border(lipgloss.RoundedBorder()).
		BorderForeground(clCyan).
		Padding(0, 2).
		Render(strings.Join(lines, "\n"))
	return lipgloss.NewStyle().
		Width(m.width-2).
		Height(m.height-3).
		Align(lipgloss.Center, lipgloss.Center).
		Render(box)
}

// ---------- тосты ----------
func (m tuiModel) renderToasts() string {
	if len(m.toasts) == 0 {
		return ""
	}
	var parts []string
	for _, t := range m.toasts {
		c := clBlue
		switch t.kind {
		case "ok":
			c = clGreen
		case "err":
			c = clRed
		case "info":
			c = clYellow
		}
		parts = append(parts, lipgloss.NewStyle().Foreground(c).Render("  • "+t.msg))
	}
	return strings.Join(parts, "\n")
}

// ---------- рендер строк транскрипта ----------
func renderLine(l tline) string {
	switch l.kind {
	case "user":
		return lipgloss.NewStyle().Bold(true).Foreground(clBlue).Render("› ") + l.text
	case "think":
		return lipgloss.NewStyle().Faint(true).Foreground(clAccent).Render("💭 " + l.text)
	case "tool":
		return lipgloss.NewStyle().Foreground(clCyan).Render(l.text)
	case "result":
		lines := strings.SplitN(l.text, "\n", 2)
		out := lipgloss.NewStyle().Foreground(clGreen).Render(lines[0])
		if len(lines) > 1 {
			out += "\n" + lipgloss.NewStyle().Foreground(clMuted).Render(lines[1])
		}
		return out
	case "info":
		return lipgloss.NewStyle().Foreground(clMuted).Render(l.text)
	case "err":
		return lipgloss.NewStyle().Foreground(clRed).Render(l.text)
	case "answer":
		return renderMarkdownLite(l.text)
	default: // stream
		return lipgloss.NewStyle().Foreground(clFG).Render(l.text)
	}
}

// refreshTranscript — перерисовка истории текущего чата во viewport.
func (m *tuiModel) refreshTranscript() {
	if len(m.sessions) == 0 {
		return
	}
	s := m.sessions[m.cur]
	s.mu.Lock()
	lines := make([]tline, len(s.lines))
	copy(lines, s.lines)
	s.mu.Unlock()
	if len(lines) > 600 {
		lines = lines[len(lines)-600:]
	}
	var b strings.Builder
	for _, l := range lines {
		b.WriteString(renderLine(l))
		b.WriteByte('\n')
	}
	m.vp.SetContent(strings.TrimRight(b.String(), "\n"))
	m.vp.GotoBottom()
}

// ---------- точка входа ----------
func runBubbleTUI(cfg Config, llm *LLMClient, workdir string, plugins []*Plugin) int {
	llm.BaseURL = strings.TrimRight(providerDefs[0].Base, "/")
	m := newTuiModel(cfg, llm, workdir, plugins)
	p := tea.NewProgram(m, tea.WithAltScreen(), tea.WithMouseCellMotion())
	globalProgram = p
	m.prog = p
	if _, err := p.Run(); err != nil {
		fmt.Fprintln(os.Stderr, "TUI:", err)
		return 1
	}
	m.bz.Close()
	return 0
}

// ---------- проверка TLS/сети (./gomni -test-net) ----------
func runNetTest() {
	ms, err := fetchModels(providerDefs[0].Name, Config{})
	if err != nil {
		fmt.Println("✗ сеть/TLS:", err)
		fmt.Println("  подсказка: SSL_CERT_FILE=путь — свой бандл, -insecure — без проверки")
		os.Exit(1)
	}
	fmt.Println("✓ TLS-фикс работает, открыт https://opencode.ai/zen/v1/models")
	fmt.Println("  модели OpenCode Zen Free:")
	for _, id := range ms {
		fmt.Println("   -", id)
	}
	os.Exit(0)
}

var _ = time.Now

// toastMsg is an external notification injected into the TUI (e.g. from tools).
type toastMsg struct{ kind, msg string }

var globalProgram *tea.Program

func init() {
	notifyApp = func(title, text string) {
		if globalProgram != nil {
			globalProgram.Send(toastMsg{kind: "info", msg: title + ": " + text})
		}
	}
}

// ---------- статус-бар: контекст, текущий ход, очередь, todo (на широких экранах) ----------
func (m tuiModel) renderStatusBar() string {
	s := m.sessions[m.cur]
	chars, pct := s.agent.ContextStatus()
	ctxCol := clGreen
	if pct >= 70 {
		ctxCol = clOrange
	}
	if pct >= 90 {
		ctxCol = clRed
	}
	seg := func(txt string, col lipgloss.TerminalColor) string {
		return lipgloss.NewStyle().Foreground(col).Render(txt)
	}
	parts := []string{
		seg(fmt.Sprintf(" %s %d%% (%s)", T("status.ctx"), pct, humanCount(chars)), ctxCol),
		seg(fmt.Sprintf("%s %d", T("status.turn"), s.agent.Turn), clCyan),
		seg(fmt.Sprintf("%s %d", T("status.tok"), s.agent.TotalTok), clMuted),
	}
	s.mu.Lock()
	qlen := len(s.queue)
	s.mu.Unlock()
	if qlen > 0 {
		parts = append(parts, seg(fmt.Sprintf("%s %d", T("status.queue"), qlen), clOrange))
	}
	if s.running {
		parts = append(parts, seg(T("status.running"), clGreen))
	}
	bar := strings.Join(parts, lipgloss.NewStyle().Foreground(clBorder).Render("  │  "))
	return lipgloss.NewStyle().Foreground(clMuted).Render("──── ") + bar
}

// renderTodos — панель плана (только на больших экранах, не на телефоне).
func (m tuiModel) renderTodos() string {
	if m.width < 120 || len(currentTodos) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString(lipgloss.NewStyle().Bold(true).Foreground(clPurple).Render(T("plan")))
	shown := 0
	for _, t := range currentTodos {
		if shown >= 8 {
			b.WriteString(lipgloss.NewStyle().Foreground(clMuted).Render(fmt.Sprintf("  +%d ещё", len(currentTodos)-shown)))
			break
		}
		icon, col := "○", clMuted
		switch t.Status {
		case "doing":
			icon, col = "◐", clOrange
		case "done":
			icon, col = "●", clGreen
		}
		b.WriteString(lipgloss.NewStyle().Foreground(col).Render(fmt.Sprintf(" %s %s", icon, trunc(t.Text, 30))))
		shown++
	}
	return b.String()
}

func humanCount(n int) string {
	if n >= 1000000 {
		return fmt.Sprintf("%.1fM", float64(n)/1e6)
	}
	if n >= 1000 {
		return fmt.Sprintf("%.1fK", float64(n)/1e3)
	}
	return fmt.Sprintf("%d", n)
}

func orDefault(s, def string) string {
	if s == "" {
		return def
	}
	return s
}

// maskKey маскирует ключ: показываем первые 3 и последние 3 символа.
func maskKey(k string) string {
	if k == "" {
		return T("key.none")
	}
	r := []rune(k)
	if len(r) <= 8 {
		return strings.Repeat("•", len(r))
	}
	return string(r[:3]) + "…" + string(r[len(r)-3:])
}

// providerKeyStatus — какой ключ сейчас действует у текущего провайдера.
func (m tuiModel) providerKeyStatus() string {
	if p := providerBy(m.provider); p.KeyFrom != nil {
		return p.KeyFrom(m.cfg)
	}
	return m.llm.APIKey
}

// renderAgentsList — список агентов на главной: имя чата + статус (в процессе/готово).
func (m tuiModel) renderAgentsList() string {
	type agentRow struct{ name, status string }
	var running, done []agentRow
	for _, s := range m.sessions {
		s.mu.Lock()
		hasWork := false
		for _, l := range s.lines {
			if l.kind == "user" {
				hasWork = true
				break
			}
		}
		r := agentRow{name: s.name}
		if s.title != "" {
			r.name = s.title
		}
		s.mu.Unlock()
		if s.running {
			r.status = T("agents.running")
			running = append(running, r)
		} else if hasWork {
			r.status = T("agents.done")
			done = append(done, r)
		}
	}
	if len(running)+len(done) == 0 {
		return ""
	}
	var b strings.Builder
	b.WriteString(lipgloss.NewStyle().Bold(true).Foreground(clBlue).Render(T("agents.title")))
	for _, r := range running {
		b.WriteString("\n  " + lipgloss.NewStyle().Foreground(clOrange).Render("◐ ") +
			lipgloss.NewStyle().Foreground(clFG).Render(trunc(r.name, 34)) + " " +
			lipgloss.NewStyle().Foreground(clOrange).Render(r.status))
	}
	for i, r := range done {
		if i >= 6 {
			b.WriteString("\n  " + lipgloss.NewStyle().Foreground(clMuted).Render(fmt.Sprintf("+%d ещё", len(done)-6)))
			break
		}
		b.WriteString("\n  " + lipgloss.NewStyle().Foreground(clGreen).Render("● ") +
			lipgloss.NewStyle().Foreground(clMuted).Render(trunc(r.name, 34)) + " " +
			lipgloss.NewStyle().Foreground(clMuted).Render(r.status))
	}
	return b.String()
}

// mainColWidth — фактическая ширина основной колонки (без панели чатов).
func (m tuiModel) mainColWidth() int {
	w := m.width - 2
	if (m.sidebar || m.sidebarAnim > 0) && m.width >= 96 {
		sbW := 4 + m.sidebarAnim*3 + m.sidebarAnim/4
		if sbW > 30 {
			sbW = 30
		}
		w -= sbW
	}
	return w
}

// inputWidthFor: на пустом экране — крупный бокс ~60% колонки (как на референсе),
// в чате — на всю ширину.
func (m tuiModel) inputWidthFor(empty bool) int {
	w := m.mainColWidth() - 6
	if empty && w > 40 {
		half := w * 3 / 5
		if half > 40 {
			return half
		}
	}
	if w < 20 {
		w = 20
	}
	return w
}
