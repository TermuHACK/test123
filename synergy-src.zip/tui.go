// GOMNI TUI v3 — Bubble Tea (в стиле OpenCode): центр-ввод + приветствие,
// правая панель чатов/сессий по рабочим папкам, верхние кнопки, окно
// параметров, мышь, уведомления, параллельные агенты в нескольких чатах.

package main

import (
	"context"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"net/http"
	"os"

	"path/filepath"
	"sort"
	"strings"
	"sync"
	"time"

	"github.com/charmbracelet/bubbles/viewport"
	"github.com/charmbracelet/bubbletea"
	"github.com/charmbracelet/lipgloss"
)

// ---------- палитра Tokyo Night (как у opencode) ----------
var (
	clAccent = lipgloss.Color("#c099ff")
	clBlue   = lipgloss.Color("#82aaff")
	clCyan   = lipgloss.Color("#86e1fc")
	clGreen  = lipgloss.Color("#c3e88d")
	clYellow = lipgloss.Color("#ffc777")
	clRed    = lipgloss.Color("#ff757f")
	clMuted  = lipgloss.Color("#636da6")
	clFG     = lipgloss.Color("#c8d3f5")
	clBG     = lipgloss.Color("#1a1b26")
	clSel    = lipgloss.Color("#2f334d")
	clOrange = lipgloss.Color("#ff966c")
	clPurple = lipgloss.Color("#c099ff")
	clBorder = lipgloss.Color("#3b4261")
)

// ---------- Провайдеры (только 3) ----------
type providerDef struct {
	Name    string
	Base    string
	KeyFrom func(Config) string
	Free    bool
}

var providerDefs = []providerDef{
	{Name: "OpenRouter Free", Base: "https://openrouter.ai/api/v1", Free: true, KeyFrom: func(c Config) string {
		if k := os.Getenv("OPENROUTER_API_KEY"); k != "" {
			return k
		}
		if c.Providers != nil {
			if pc, ok := c.Providers["OpenRouter Free"]; ok && pc != nil && pc.APIKey != "" {
				return pc.APIKey
			}
			if pc, ok := c.Providers["OpenRouter"]; ok && pc != nil && pc.APIKey != "" {
				return pc.APIKey
			}
		}
		return c.APIKey
	}},
	{Name: "OpenRouter", Base: "https://openrouter.ai/api/v1", KeyFrom: func(c Config) string {
		if k := os.Getenv("OPENROUTER_API_KEY"); k != "" {
			return k
		}
		if c.Providers != nil {
			if pc, ok := c.Providers["OpenRouter"]; ok && pc != nil && pc.APIKey != "" {
				return pc.APIKey
			}
		}
		return c.APIKey
	}},
	// Zen Free с 2026 закрыт для сторонних клиентов: сервер требует session id из их бэкенда
	// (ошибка MissingSessionID). Оставлен для совместимости списка; при 400 покажем подсказку.
	{Name: "OpenCode Zen Free", Base: "https://opencode.ai/zen/v1", Free: true},
	{Name: "OpenCode Zen", Base: "https://opencode.ai/zen/v1", KeyFrom: func(c Config) string {
		if c.Providers != nil {
			if pc, ok := c.Providers["OpenCode Zen"]; ok && pc != nil && pc.APIKey != "" {
				return pc.APIKey
			}
		}
		return c.APIKey
	}},
}

func providerBy(name string) *providerDef {
	for i := range providerDefs {
		if providerDefs[i].Name == name {
			return &providerDefs[i]
		}
	}
	return &providerDefs[0]
}

func providerShort(name string) string {
	switch name {
	case providerDefs[0].Name:
		return "ZEN-FREE"
	case providerDefs[1].Name:
		return "ZEN"
	}
	return "ROUTER"
}

// ---------- фетчинг актуальных моделей ----------
func fetchModels(name string, cfg Config) ([]string, error) {
	p := providerBy(name)
	base := strings.TrimRight(p.Base, "/")
	req, err := http.NewRequest("GET", base+"/models", nil)
	if err != nil {
		return nil, err
	}
	if p.KeyFrom != nil {
		if k := p.KeyFrom(cfg); k != "" {
			req.Header.Set("Authorization", "Bearer "+k)
		}
	}
	req.Header.Set("User-Agent", "gomni/3.0")
	resp, err := sharedHTTPClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 400 {
		return nil, fmt.Errorf("GET %s/models → %d", base, resp.StatusCode)
	}
	var out struct {
		Data []struct {
			ID string `json:"id"`
		} `json:"data"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&out); err != nil {
		return nil, err
	}
	var ids []string
	seen := map[string]bool{}
	for _, d := range out.Data {
		if d.ID != "" && !seen[d.ID] {
			seen[d.ID] = true
			ids = append(ids, d.ID)
		}
	}
	if len(ids) == 0 {
		return nil, fmt.Errorf("провайдер %s вернул пустой список моделей", name)
	}
	sort.Strings(ids)
	if p.Free {
		var free []string
		isOR := strings.Contains(p.Base, "openrouter")
		for _, id := range ids {
			low := strings.ToLower(id)
			if isOR {
				if strings.HasSuffix(low, ":free") { // OpenRouter: бесплатные помечены суффиксом :free
					free = append(free, id)
				}
			} else if strings.Contains(low, "free") { // Zen: -free в id
				free = append(free, id)
			}
		}
		if !isOR && seen["big-pickle"] {
			has := false
			for _, f := range free {
				if f == "big-pickle" {
					has = true
				}
			}
			if !has {
				free = append([]string{"big-pickle"}, free...)
			}
		}
		if len(free) == 0 {
			if isOR {
				return nil, fmt.Errorf("нет :free моделей — проверь ключ OpenRouter (Ctrl+S → K)")
			}
			free = zenModelIDs
		}
		return free, nil
	}
	if len(ids) > 250 {
		ids = ids[:250]
	}
	return ids, nil
}

// ---------- уведомления ----------
// ВАЖНО: exec.LookPath / exec.Command с голым именем внутри вызывают faccessat2,
// который Android-ядро на 32-бит ARM режет через seccomp (SIGSYS). Только LookPathSafe.
func haveTermuxNotify() bool {
	_, err := LookPathSafe("termux-notification")
	return err == nil
}

// notifySystem: системное уведомление — termux-notification (Android) или
// кастомная команда GOMNI_NOTIFY_CMD с плейсхолдером {msg}. На десктопе — no-op.
func notifySystem(title, body string) {
	body = strings.NewReplacer("\n", " ", "`", "").Replace(body)
	if len(body) > 200 {
		body = trunc(body, 200)
	}
	if cmdline := os.Getenv("GOMNI_NOTIFY_CMD"); cmdline != "" {
		c := strings.ReplaceAll(cmdline, "{msg}", title+": "+body)
		runRawDetached(shPath(), "-c", c) // raw fork+exec: обход pidfd_open (SIGSYS на ARM)
		return
	}
	if p, err := LookPathSafe("termux-notification"); err == nil {
		runRawDetached(p, "--title", "SYNERGY", "--content", title+": "+body)
	}
}

// ---------- модель TUI ----------
type toast struct {
	kind string // ok | err | info
	msg  string
	born time.Time
}

type tline struct {
	kind string // user | think | tool | result | info | stream | answer | err
	text string
}

type chatSession struct {
	id      int
	name    string
	workdir string
	agent   *Agent
	cancel  context.CancelFunc
	running bool
	title   string
	mu      sync.Mutex
	lines   []tline
	queue   []string // queued messages: длинные сообщения, отправленные пока агент занят
}

type tuiModel struct {
	width, height    int
	bz               *zoneMgr
	sessions         []*chatSession
	cur              int
	input            mlEditor
	vp               viewport.Model
	provider         string
	model            string
	models           []string
	reasoning        int // 0..2
	cfg              Config
	workdir          string
	llm              *LLMClient
	plugins          []*Plugin
	settings         bool
	sidebar          bool
	picker           bool
	pickerMode       string
	pickerTitle      string
	pickerItems      []string
	pickerSel        int
	toasts           []toast
	prog             *tea.Program
	nextSID          int
	ctrlEnterNewline bool     // настройка: Ctrl+Enter = перенос (десктоп), Enter = отправка
	hist             []string // история ввода (Ctrl+P — назад)
	histIdx          int
	keyEdit          bool   // режим ввода API-ключа провайдера (Ctrl+S → K)
	keyBuf           string // буфер ключа (не эхоится — рисуем звёздочки)
	provStep         int    // 0=выкл, 1=имя, 2=base URL, 3=ключ — мастер кастомного провайдера
	provName         string
	provURL          string
	provBuf          string
	pendingImages    []string // data-URL изображения, прикреплённые к следующему сообщению
	pendingCmd       tea.Cmd  // команда из автодополнения — исполняется ближайшим Update
	failoverOn       bool
	failoverTarget   string
	sidebarRight     bool // панель чатов справа (по умолчанию слева)
	sidebarAnim      int  // 0..8 — прогресс анимации выезда панели (8 = полностью открыта)
	sidebarTarget    bool // куда анимируем (true = открывается)
	compl            completionState
}

// completionState — автодополнение команд над полем ввода.
type completionState struct {
	visible bool
	items   []string
	sel     int
}

// ---------- сообщения между горутинами агентов и TUI ----------
type chatDeltaMsg struct {
	sid  int
	kind string
	text string
}

type chatDoneMsg struct {
	sid int
	err error
}

type modelsFetchedMsg struct {
	ms  []string
	err error
}

type tickMsg time.Time

// modelsFetchCmdMsg — внутренний триггер: перефетчить модели (после фейловера).
type modelsFetchCmdMsg struct{}

func newTuiModel(cfg Config, llm *LLMClient, workdir string, plugins []*Plugin) *tuiModel {
	m := &tuiModel{
		cfg: cfg, llm: llm, workdir: workdir, plugins: plugins,
		failoverOn: true, failoverTarget: cfg.FailoverTarget,
		sidebarRight: cfg.SidebarSide == "right",
		provider:     providerDefs[0].Name,
		model:        "(загружаю…)",
		models:       zenModelIDs,
		reasoning:    1,
		sidebar:      false, // панель чатов закрыта по умолчанию — открывается анимацией (☰ или Ctrl+L)
		width:        108, height: 30,
		bz: newZoneMgr(),
	}
	m.input = newMlEditor()
	m.input.width = 90
	m.vp = viewport.New(80, 20)
	m.vp.MouseWheelEnabled = true
	m.hist = loadInputHistory()
	m.histIdx = len(m.hist)
	setUILang(orDefault(cfg.Lang, "ru"))
	restoreCustomProviders(cfg)
	llm.OnRetry = func(msg string) {
		if m.prog != nil {
			m.prog.Send(toastMsg{kind: "err", msg: msg})
		}
	}
	m.addSession(workdir)
	return m
}

func (m *tuiModel) addSession(wd string) int {
	if wd == "" {
		wd = m.workdir
	}
	id := m.nextSID
	m.nextSID++
	s := &chatSession{id: id, name: fmt.Sprintf("chat%d", id+1), workdir: wd}
	s.agent = NewAgent(m.llm, wd, m.plugins...)
	attachMCP(s.agent) // MCP-тулы из mcp.json
	loadNamedSession(s.agent, s.name)
	s.mu.Lock()
	s.lines = append(s.lines, tline{"info", "рабочая папка: " + wd})
	s.mu.Unlock()
	m.sessions = append(m.sessions, s)
	return len(m.sessions) - 1
}

func (m *tuiModel) closeCurrent() {
	if len(m.sessions) <= 1 {
		m.addToast("err", "нельзя закрыть единственный чат")
		return
	}
	s := m.sessions[m.cur]
	if s.cancel != nil {
		s.cancel()
	}
	m.sessions = append(m.sessions[:m.cur], m.sessions[m.cur+1:]...)
	if m.cur >= len(m.sessions) {
		m.cur = len(m.sessions) - 1
	}
	m.refreshTranscript()
}

func (m *tuiModel) switchProvider(name string) bool {
	for _, p := range providerDefs {
		if p.Name == name {
			m.provider = name
			m.llm.BaseURL = strings.TrimRight(p.Base, "/")
			if p.KeyFrom != nil {
				if k := p.KeyFrom(m.cfg); k != "" {
					m.llm.APIKey = k
				}
			}
			return true
		}
	}
	return false
}

func (m *tuiModel) openPicker(mode, title string, items []string) {
	m.picker = true
	m.pickerMode = mode
	m.pickerTitle = title
	m.pickerItems = items
	m.pickerSel = 0
}

func (m *tuiModel) addToast(kind, msg string) {
	m.toasts = append(m.toasts, toast{kind: kind, msg: msg, born: time.Now()})
	if len(m.toasts) > 4 {
		m.toasts = m.toasts[len(m.toasts)-4:]
	}
}

// ---------- Init ----------
func (m tuiModel) Init() tea.Cmd {
	return tea.Batch(
		m.fetchCmd(),
		tea.Tick(3*time.Second, func(t time.Time) tea.Msg { return tickMsg(t) }),
	)
}

func (m *tuiModel) fetchCmd() tea.Cmd {
	prov, cfg := m.provider, m.cfg
	return func() tea.Msg {
		ms, err := fetchModels(prov, cfg)
		return modelsFetchedMsg{ms: ms, err: err}
	}
}

// ---------- запуск агента (параллельный) ----------
func (m *tuiModel) launchAgent(sid int, prompt string) tea.Cmd {
	return func() tea.Msg {
		s := m.sessions[sid]
		s.mu.Lock()
		s.lines = append(s.lines, tline{"user", prompt})
		s.title = trunc(prompt, 40)
		s.mu.Unlock()
		ctx, cancel := context.WithCancel(context.Background())
		s.cancel = cancel
		s.running = true
		a := s.agent
		a.StreamUI = true // стримим текст в TUI через события
		a.MaxSteps = []int{8, 25, 40}[m.reasoning]
		a.OnEvent = func(ev AgentEvent) {
			switch ev.Kind {
			case "think", "answer", "answer_done":
				return // текст уже стримится через "delta"
			}
			var k string
			switch ev.Kind {
			case "tool_call":
				k = "tool"
			case "tool_result":
				k = "result"
			case "info":
				k = "info"
			case "delta":
				k = "stream"
			}
			if m.prog != nil {
				m.prog.Send(chatDeltaMsg{sid: sid, kind: k, text: renderEventText(ev)})
			}
		}
		_, err := a.Run(ctx, prompt)
		// Фейловер: провайдер лёг (4 попытки + 5 мин паузы не помогли) — переключаемся и повторяем.
		if err != nil && strings.Contains(err.Error(), "provider_down") && m.failoverOn && ctx.Err() == nil {
			target := m.failoverTarget
			if target == "" || target == m.provider { // auto: следующий по списку
				for i, p := range providerDefs {
					if p.Name == m.provider {
						target = providerDefs[(i+1)%len(providerDefs)].Name
						break
					}
				}
			}
			if target != "" && m.switchProvider(target) {
				m.prog.Send(toastMsg{kind: "info", msg: "⚡ фейловер: " + m.provider + " → " + target})
				if m.prog != nil {
					m.prog.Send(modelsFetchCmdMsg{})
				}
				a.LLM = m.llm // агент ходит на нового провайдера
				_, err = a.Run(ctx, prompt)
			}
		}
		s.running = false
		if s.cancel != nil {
			s.cancel = nil
		}
		saveNamedSession(a, s.name)
		return chatDoneMsg{sid: sid, err: err}
	}
}

func renderEventText(ev AgentEvent) string {
	switch ev.Kind {
	case "tool_call":
		return "⚙ " + ev.Title + " " + trunc(ev.Body, 90)
	case "tool_result":
		return "✓ " + ev.Title + " (" + ev.Elapsed.Round(time.Millisecond).String() + ")\n    " + trunc(ev.Body, 300)
	case "info":
		return ev.Body
	}
	return ev.Body
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// clipboardPasteCmd читает системный буфер (termux-clipboard-get) и вставляет в редактор.
// OSC52-запрос терминалу не делаем — Termux его не отвечает; полагаемся на termux-api.
func clipboardPasteCmd() tea.Cmd {
	return func() tea.Msg {
		p, err := LookPathSafe("termux-clipboard-get")
		if err != nil {
			return toastMsg{kind: "err", msg: "буфер недоступен: установи termux-api"}
		}
		out, err := runRawOutput(context.Background(), 10*time.Second, p)
		if err != nil {
			return toastMsg{kind: "err", msg: "clipboard: " + err.Error()}
		}
		return pasteMsg{text: out}
	}
}

// clipboardCopyOSC52 копирует текст в терминальный буфер через OSC52 escape
// (работает в Termux, iTerm2, tmux с set-clipboard). Плюс termux-clipboard-set как фолбэк.
func clipboardCopyOSC52(text string) {
	enc := base64.StdEncoding.EncodeToString([]byte(text))
	fmt.Fprintf(os.Stderr, "\x1b]52;c;%s\x07", enc)
	if p, err := LookPathSafe("termux-clipboard-set"); err == nil {
		_ = runRawInput(context.Background(), 10*time.Second, text, p)
	}
}

type pasteMsg struct{ text string }

// ---------- Update ----------
func (m tuiModel) Update(msg tea.Msg) (tea.Model, tea.Cmd) {
	switch msg := msg.(type) {
	case tea.WindowSizeMsg:
		m.width, m.height = msg.Width, msg.Height
		m.layout()
		return m, nil

	case tea.MouseMsg:
		return m.handleMouse(msg)

	case tea.KeyMsg:
		if m.pendingCmd != nil {
			cmd := m.pendingCmd
			m.pendingCmd = nil
			m2, c2 := m.handleKey(msg)
			return m2, tea.Batch(cmd, c2)
		}
		return m.handleKey(msg)

	case chatDeltaMsg:
		s := m.sessions[msg.sid]
		s.mu.Lock()
		n := len(s.lines)
		if msg.kind == "stream" && n > 0 && s.lines[n-1].kind == "stream" {
			s.lines[n-1].text += msg.text
			if len(s.lines[n-1].text) > 4000 {
				s.lines[n-1].text = s.lines[n-1].text[:4000] + "…"
			}
		} else {
			s.lines = append(s.lines, tline{msg.kind, msg.text})
		}
		s.mu.Unlock()
		if msg.sid == m.cur {
			m.refreshTranscript()
		}
		return m, nil

	case chatDoneMsg:
		s := m.sessions[msg.sid]
		s.running = false
		s.mu.Lock()
		n := len(s.lines)
		if msg.err != nil {
			errTxt := msg.err.Error()
			switch {
			case strings.Contains(errTxt, "MissingSessionID") || strings.Contains(errTxt, "can only be used in OpenCode"):
				errTxt = "OpenCode Zen Free закрыт для сторонних клиентов (нужен session id их бэкенда). Переключись на OpenRouter Free: /provider OpenRouter Free"
			case strings.Contains(errTxt, "API 401") || strings.Contains(errTxt, "API 403"):
				errTxt = errTxt + " — проверь ключ: Ctrl+S → K"
			}
			s.lines = append(s.lines, tline{"err", "✗ " + errTxt})
		} else if n == 0 || s.lines[n-1].kind != "stream" {
			s.lines = append(s.lines, tline{"answer", "(ответ выше)"})
		}
		// очередь сообщений: берём следующее, если есть
		var next string
		if len(s.queue) > 0 && msg.err == nil {
			next = s.queue[0]
			s.queue = s.queue[1:]
		}
		qlen := len(s.queue)
		s.mu.Unlock()
		if msg.sid == m.cur {
			m.refreshTranscript()
		}
		if next != "" {
			m.addToast("info", fmt.Sprintf("запускаю из очереди (осталось %d)", qlen))
			return m, m.launchAgent(msg.sid, next)
		}
		m.addToast("ok", "чат "+s.name+" завершён")
		notifySystem("SYNERGY", "чат "+s.name+" готов")
		return m, nil

	case modelsFetchCmdMsg:
		return m, m.fetchCmd()
	case modelsFetchedMsg:
		if msg.err != nil {
			m.addToast("err", "модели: "+msg.err.Error())
			if strings.Contains(providerBy(m.provider).Base, "opencode") {
				m.models = zenModelIDs
			}
		} else {
			m.models = msg.ms
			if len(m.models) > 0 && !containsStr(m.models, m.model) {
				m.model = m.models[0]
			}
			m.addToast("ok", fmt.Sprintf("моделей у %s: %d", providerShort(m.provider), len(m.models)))
		}
		return m, nil

	case toastMsg:
		m.addToast(msg.kind, msg.msg)
	case pasteMsg:
		m.input.insertText(msg.text)
	case sidebarAnimMsg:
		return m, m.stepSidebarAnim()
	case tickMsg:
		now := time.Time(msg)
		keep := m.toasts[:0]
		for _, t := range m.toasts {
			if now.Sub(t.born) < 6*time.Second {
				keep = append(keep, t)
			}
		}
		m.toasts = keep
		return m, tea.Tick(3*time.Second, func(t time.Time) tea.Msg { return tickMsg(t) })
	}
	return m, nil
}

func containsStr(xs []string, s string) bool {
	for _, x := range xs {
		if x == s {
			return true
		}
	}
	return false
}

// toggleSidebar запускает анимацию выезда/заезда панели чатов.
func (m *tuiModel) toggleSidebar() tea.Cmd {
	m.sidebarTarget = !m.sidebarTarget
	return tea.Tick(45*time.Millisecond, func(t time.Time) tea.Msg { return sidebarAnimMsg(t) })
}

type sidebarAnimMsg time.Time

// stepSidebarAnim двигает анимацию на кадр; возвращает команду следующего кадра или nil.
func (m *tuiModel) stepSidebarAnim() tea.Cmd {
	if m.sidebarTarget {
		m.sidebar = true
		if m.sidebarAnim < 8 {
			m.sidebarAnim++
			m.layout()
			return tea.Tick(45*time.Millisecond, func(t time.Time) tea.Msg { return sidebarAnimMsg(t) })
		}
	} else {
		if m.sidebarAnim > 0 {
			m.sidebarAnim--
			m.layout()
			return tea.Tick(45*time.Millisecond, func(t time.Time) tea.Msg { return sidebarAnimMsg(t) })
		}
		m.sidebar = false
		m.layout()
	}
	return nil
}

// ---------- клавиатура ----------
func (m tuiModel) handleKey(msg tea.KeyMsg) (tea.Model, tea.Cmd) {
	key := msg.String()
	switch key {
	case "ctrl+c", "ctrl+q":
		return m, tea.Quit
	}

	if m.picker {
		switch key {
		case "up", "k":
			if m.pickerSel > 0 {
				m.pickerSel--
			}
			return m, nil
		case "down", "j":
			if m.pickerSel < len(m.pickerItems)-1 {
				m.pickerSel++
			}
			return m, nil
		case "enter":
			return m.applyPicker()
		case "esc":
			m.picker = false
			return m, nil
		}
	}

	if m.provStep > 0 {
		switch key {
		case "esc":
			m.provStep, m.provBuf, m.provName, m.provURL = 0, "", "", ""
			return m, nil
		case "enter":
			v := strings.TrimSpace(m.provBuf)
			m.provBuf = ""
			switch m.provStep {
			case 1:
				if v == "" {
					return m, nil
				}
				m.provName, m.provStep = v, 2
			case 2:
				if !strings.HasPrefix(v, "http") {
					m.addToast("err", "URL должен начинаться с http(s)://")
					return m, nil
				}
				m.provURL, m.provStep = strings.TrimRight(v, "/"), 3
			case 3:
				m.addCustomProvider(m.provName, m.provURL, v)
				m.provStep = 0
				return m, m.fetchCmd()
			}
			return m, nil
		case "backspace":
			if r := []rune(m.provBuf); len(r) > 0 {
				m.provBuf = string(r[:len(r)-1])
			}
			return m, nil
		case " ":
			m.provBuf += " "
			return m, nil
		default:
			if msg.Type == tea.KeyRunes {
				m.provBuf += string(msg.Runes)
			}
			return m, nil
		}
	}

	if m.settings && m.keyEdit {
		switch key {
		case "esc":
			m.keyEdit = false
			m.keyBuf = ""
			return m, nil
		case "enter":
			m.saveProviderKey(m.keyBuf)
			m.keyEdit = false
			m.keyBuf = ""
			return m, m.fetchCmd() // ключ сменился — перефетчим модели
		case "backspace":
			if len(m.keyBuf) > 0 {
				r := []rune(m.keyBuf)
				m.keyBuf = string(r[:len(r)-1])
			}
			return m, nil
		default:
			if msg.Type == tea.KeySpace {
				m.keyBuf += " "
			} else if msg.Type == tea.KeyRunes {
				m.keyBuf += string(msg.Runes)
			}
			return m, nil
		}
	}

	if m.settings {
		switch key {
		case "esc":
			m.settings = false
			m.saveSettings()
			return m, nil
		case "left":
			m.cycleProvider(-1)
			return m, nil
		case "right":
			m.cycleProvider(1)
			return m, nil
		case "r", "R":
			m.reasoning = (m.reasoning + 1) % 3
			return m, nil
		case "l", "L":
			if uiLang == "ru" {
				setUILang("en")
			} else {
				setUILang("ru")
			}
			m.addToast("ok", T("toast.lang")+uiLang)
			return m, nil
		case "f", "F":
			m.failoverOn = !m.failoverOn
			onoff := "off"
			if m.failoverOn {
				onoff = "on"
			}
			m.addToast("ok", T("toast.failover")+onoff)
			return m, nil
		case "b", "B":
			m.sidebarRight = !m.sidebarRight
			side := T("left")
			if m.sidebarRight {
				side = T("right")
			}
			m.addToast("ok", T("toast.sidebar")+side)
			m.layout()
			return m, nil
		case "e", "E":
			m.ctrlEnterNewline = !m.ctrlEnterNewline
			return m, nil
		case "k", "K":
			m.keyEdit = true
			m.keyBuf = ""
			return m, nil
		case "enter", "m":
			if len(m.models) > 0 {
				m.openPicker("models", "Модели — "+m.provider, m.models)
			}
			return m, nil
		}
	}

	switch key {
	case "ctrl+n":
		m.addSession(m.workdir)
		m.cur = len(m.sessions) - 1
		m.refreshTranscript()
		return m, nil
	case "ctrl+s":
		m.settings = !m.settings
		return m, nil
	case "ctrl+l":
		return m, m.toggleSidebar()
	case "ctrl+m":
		if len(m.models) > 0 {
			m.openPicker("models", "Модели — "+m.provider, m.models)
		}
		return m, nil
	case "esc":
		if m.compl.visible {
			m.compl.visible = false
			return m, nil
		}
		m.settings = false
		return m, nil
	case "enter":
		if m.picker {
			return m, nil
		}
		// Умный Enter (как у opencode): однострочное сообщение, команда или автодополнение — отправка.
		// Многострочный текст — Enter переносит строку, отправка через Ctrl+Enter.
		if m.compl.visible {
			m.completeApply()
			return m, nil
		}
		if m.smartEnterShouldSubmit() {
			return m, m.submitInput()
		}
		m.input.newline()
		return m, nil
	case "ctrl+j", "ctrl+enter":
		// Ctrl+Enter — принудительная отправка (или перенос, если включён «десктопный» режим)
		if m.picker {
			return m, nil
		}
		if m.ctrlEnterNewline {
			m.input.newline()
			return m, nil
		}
		return m, m.submitInput()
	case "up":
		if m.compl.visible {
			if m.compl.sel > 0 {
				m.compl.sel--
			}
			return m, nil
		}
		if m.input.cy > 0 {
			m.input.moveVert(-1)
			return m, nil
		}
		return m, nil
	case "down":
		if m.compl.visible {
			if m.compl.sel < len(m.compl.items)-1 {
				m.compl.sel++
			}
			return m, nil
		}
		if m.input.cy < len(m.input.lines)-1 {
			m.input.moveVert(1)
			return m, nil
		}
		return m, nil
	case "left":
		if m.input.cx > 0 {
			m.input.cx--
		}
		return m, nil
	case "right":
		if m.input.cx < len([]rune(m.input.lines[m.input.cy])) {
			m.input.cx++
		}
		return m, nil
	case "home", "ctrl+a":
		m.input.cx = 0
		return m, nil
	case "end", "ctrl+e":
		m.input.cx = len([]rune(m.input.lines[m.input.cy]))
		return m, nil
	case "backspace":
		m.input.backspace()
		return m, nil
	case "delete":
		m.input.deleteForward()
		return m, nil
	case "ctrl+w":
		m.input.deleteWord()
		return m, nil
	case "ctrl+u":
		m.input.lines[m.input.cy] = string([]rune(m.input.lines[m.input.cy])[m.input.cx:])
		m.input.cx = 0
		return m, nil
	case "ctrl+y":
		// вставка из буфера (OSC52/termux) — мягко, без падения
		return m, clipboardPasteCmd()
	case "tab":
		// автодополнение: список скрыт → открыть; виден → Tab применяет выбранное (как Enter)
		if m.compl.visible && len(m.compl.items) > 0 {
			m.completeApply()
			return m, nil
		}
		m.completeTab()
		return m, nil
	case "shift+tab":
		if m.compl.visible && len(m.compl.items) > 1 {
			m.compl.sel = (m.compl.sel - 1 + len(m.compl.items)) % len(m.compl.items)
		}
		return m, nil
	}

	// printable input (в т.ч. многострочная вставка — paste приходит пачкой rune/ctrl)
	// KeySpace обрабатываем явно: на десктопных терминалах bubbletea шлёт пробел
	// как KeySpace, а не KeyRunes — без этого кейса пробел «не работает».
	if msg.Type == tea.KeySpace {
		m.input.insertText(" ")
		return m, nil
	}
	if msg.Type == tea.KeyRunes {
		m.input.insertText(string(msg.Runes))
		return m, nil
	}
	if msg.Paste {
		m.input.insertText(string(msg.Runes))
		return m, nil
	}
	return m, nil
}

// smartEnterShouldSubmit: Enter отправляет, если текст однострочный/короткий/команда.
// Многострочный текст (уже есть \n) — Enter переносит строку, отправка через Ctrl+Enter.
func (m *tuiModel) smartEnterShouldSubmit() bool {
	v := m.input.Value()
	if strings.Contains(v, "\n") {
		return false
	}
	t := strings.TrimSpace(v)
	if t == "" {
		return false
	}
	if strings.HasPrefix(t, "/") {
		return true
	}
	return len([]rune(t)) <= 300
}

// submitInput — забрать текст редактора и отправить агенту / в очередь / как команду.
func (m *tuiModel) submitInput() tea.Cmd {
	line := strings.TrimRight(m.input.Value(), "\n")
	m.input.Reset()
	if t := strings.TrimSpace(line); t != "" {
		m.hist = append(m.hist, t)
		if len(m.hist) > 200 {
			m.hist = m.hist[len(m.hist)-200:]
		}
		m.histIdx = len(m.hist)
		saveInputHistory(m.hist)
	}
	if strings.TrimSpace(line) == "" {
		return nil
	}
	trimmed := strings.TrimSpace(line)
	if strings.HasPrefix(trimmed, "/") {
		return m.dispatchCommand(trimmed)
	}
	s := m.sessions[m.cur]
	if s.running {
		// агент занят: короткое сообщение — мягкий steer, длинное — в очередь
		if len([]rune(trimmed)) <= 400 {
			select {
			case s.agent.Steer <- trimmed:
				m.addToast("info", "steer принят (агент учтёт на следующем шаге)")
			default:
				m.addToast("err", "очередь steer переполнена")
			}
		} else {
			s.mu.Lock()
			s.queue = append(s.queue, line)
			s.mu.Unlock()
			m.addToast("info", fmt.Sprintf("в очереди: %d сообщ.", len(s.queue)))
		}
		return nil
	}
	return m.launchAgent(m.cur, line)
}

// completeTab — автодополнение: /команды, /provider, /model. Заполняет панель compl.
func (m *tuiModel) completeTab() {
	cur := m.input.Value()
	if !strings.HasPrefix(cur, "/") || strings.Contains(cur, "\n") {
		m.compl.visible = false
		return
	}
	fields := strings.Fields(cur)
	var cands []string
	if len(fields) <= 1 {
		for _, c := range slashCommands {
			if strings.HasPrefix(c, cur) {
				cands = append(cands, c)
			}
		}
	} else if fields[0] == "/provider" {
		tail := strings.ToLower(fields[len(fields)-1])
		for _, p := range providerDefs {
			if strings.HasPrefix(strings.ToLower(p.Name), tail) {
				cands = append(cands, "/provider "+p.Name)
			}
		}
	} else if fields[0] == "/model" {
		tail := fields[len(fields)-1]
		for _, md := range m.models {
			if strings.Contains(md, tail) {
				cands = append(cands, "/model "+md)
			}
		}
	}
	if len(cands) == 0 {
		m.compl.visible = false
		return
	}
	if len(cands) == 1 {
		m.input.Reset()
		m.input.insertText(cands[0])
		m.compl.visible = false
		return
	}
	m.compl = completionState{visible: true, items: cands, sel: 0}
}

// completeApply — применить выбранный вариант автодополнения (Enter или Tab).
// Команда без аргументов исполняется сразу; с аргументами — подставляется в поле.
func (m *tuiModel) completeApply() {
	if !m.compl.visible || len(m.compl.items) == 0 {
		return
	}
	pick := m.compl.items[m.compl.sel]
	m.compl.visible = false
	m.input.Reset()
	m.input.insertText(pick)
	if noArg := strings.HasPrefix(pick, "/") && len(strings.Fields(pick)) == 1; noArg {
		if cmd := m.dispatchCommand(strings.TrimSpace(pick)); cmd != nil {
			m.input.Reset()
			m.pendingCmd = cmd
		}
	}
}

// addCustomProvider регистрирует кастомный OpenAI-совместимый провайдер и сохраняет в конфиг.
func (m *tuiModel) addCustomProvider(name, baseURL, key string) {
	providerDefs = append(providerDefs, providerDef{
		Name: name, Base: baseURL,
		KeyFrom: func(c Config) string {
			if c.Providers != nil {
				if pc, ok := c.Providers[name]; ok && pc != nil {
					return pc.APIKey
				}
			}
			return ""
		},
	})
	if m.cfg.Providers == nil {
		m.cfg.Providers = map[string]*ProviderCfg{}
	}
	m.cfg.Providers[name] = &ProviderCfg{BaseURL: baseURL, APIKey: key}
	m.saveSettings()
	m.switchProvider(name)
	m.addToast("ok", "провайдер добавлен: "+name)
}

// restoreCustomProviders поднимает кастомных провайдеров из config.json при старте.
func restoreCustomProviders(cfg Config) {
	for name, pc := range cfg.Providers {
		if pc == nil || pc.BaseURL == "" {
			continue
		}
		if providerBy(name).Name == name && providerBy(name).Base != "" {
			known := false
			for _, p := range providerDefs {
				if p.Name == name {
					known = true
				}
			}
			if known {
				continue
			}
		}
		nm, pc2 := name, pc
		providerDefs = append(providerDefs, providerDef{
			Name: nm, Base: pc2.BaseURL,
			KeyFrom: func(c Config) string {
				if c.Providers != nil {
					if p, ok := c.Providers[nm]; ok && p != nil {
						return p.APIKey
					}
				}
				return ""
			},
		})
	}
}

// saveProviderKey сохраняет ключ текущего провайдера в config.json и применяет к живому клиенту.
func (m *tuiModel) saveProviderKey(key string) {
	key = strings.TrimSpace(key)
	if key == "" {
		m.addToast("err", "ключ пуст — не сохраняю")
		return
	}
	if m.cfg.Providers == nil {
		m.cfg.Providers = map[string]*ProviderCfg{}
	}
	pc := m.cfg.Providers[m.provider]
	if pc == nil {
		pc = &ProviderCfg{}
		m.cfg.Providers[m.provider] = pc
	}
	pc.APIKey = key
	m.llm.APIKey = key
	if data, err := json.MarshalIndent(m.cfg, "", "  "); err == nil {
		os.WriteFile(filepath.Join(getConfigDir(), "config.json"), data, 0o600)
	}
	m.addToast("ok", "ключ сохранён для "+m.provider)
}

// saveSettings сохраняет lang/failover/sidebar в config.json.
func (m *tuiModel) saveSettings() {
	m.cfg.Lang = uiLang
	m.cfg.SidebarSide = "left"
	if m.sidebarRight {
		m.cfg.SidebarSide = "right"
	}
	m.cfg.FailoverEnabled = m.failoverOn
	m.cfg.FailoverTarget = m.failoverTarget
	if data, err := json.MarshalIndent(m.cfg, "", "  "); err == nil {
		os.WriteFile(filepath.Join(getConfigDir(), "config.json"), data, 0o600)
	}
}

// ---- история ввода: ~/.config/gomni/input_history.txt ----
func inputHistoryPath() string { return filepath.Join(getConfigDir(), "input_history.txt") }

func loadInputHistory() []string {
	data, err := os.ReadFile(inputHistoryPath())
	if err != nil {
		return nil
	}
	var out []string
	for _, l := range strings.Split(string(data), "\n") {
		if l = strings.TrimRight(l, "\r"); l != "" {
			out = append(out, l)
		}
	}
	if len(out) > 200 {
		out = out[len(out)-200:]
	}
	return out
}

func saveInputHistory(hist []string) {
	if len(hist) > 200 {
		hist = hist[len(hist)-200:]
	}
	os.WriteFile(inputHistoryPath(), []byte(strings.Join(hist, "\n")), 0o600)
}

// listSavedSessions — имена сохранённых сессий на диске (для /history).
func listSavedSessions() []string {
	des, err := os.ReadDir(sessionsDir())
	if err != nil {
		return nil
	}
	var out []string
	for _, de := range des {
		if strings.HasSuffix(de.Name(), ".json") {
			out = append(out, strings.TrimSuffix(de.Name(), ".json"))
		}
	}
	return out
}

func (m *tuiModel) cycleProvider(dir int) {
	for i, p := range providerDefs {
		if p.Name == m.provider {
			ni := (i + dir + len(providerDefs)) % len(providerDefs)
			m.switchProvider(providerDefs[ni].Name)
			m.addToast("info", "провайдер: "+providerDefs[ni].Name)
			return
		}
	}
}

// ---------- мышь ----------
func (m tuiModel) handleMouse(msg tea.MouseMsg) (tea.Model, tea.Cmd) {
	if m.bz.hit("btn_new", msg) {
		m.addSession(m.workdir)
		m.cur = len(m.sessions) - 1
		m.refreshTranscript()
		return m, nil
	}
	if m.bz.hit("btn_models", msg) || m.bz.hit("chip", msg) {
		if len(m.models) > 0 && !m.picker {
			m.openPicker("models", "Модели — "+m.provider, m.models)
			return m, nil
		}
	}
	if m.bz.hit("btn_cfg", msg) {
		m.settings = !m.settings
		return m, nil
	}
	if m.bz.hit("btn_side", msg) {
		return m, m.toggleSidebar()
	}
	if m.bz.hit("btn_zen", msg) {
		m.switchProvider(m.provider)
		m.refreshTranscript()
		return m, nil
	}
	for i := range m.sessions {
		if m.bz.hit(fmt.Sprintf("sess:%d", i), msg) {
			if i != m.cur {
				m.cur = i
				m.refreshTranscript()
			}
			return m, nil
		}
	}
	// колесо — во viewport
	m.vp, _ = m.vp.Update(msg)
	return m, nil
}

func (m *tuiModel) applyPicker() (tea.Model, tea.Cmd) {
	m.picker = false
	sel := m.pickerSel
	if sel < 0 || sel >= len(m.pickerItems) {
		return m, nil
	}
	item := m.pickerItems[sel]
	var cmd tea.Cmd
	switch m.pickerMode {
	case "models":
		m.model = item
		m.llm.Model = item
		m.addToast("ok", "модель: "+item)
	case "provider":
		if item == "＋ свой провайдер (custom)" {
			m.provStep, m.provBuf = 1, ""
			m.settings = true // мастер рисуется в окне настроек
			break
		}
		if m.switchProvider(item) {
			m.addToast("ok", "провайдер: "+item)
			cmd = m.fetchCmd()
		}
	case "chat":
		if sel >= 0 && sel < len(m.sessions) {
			m.cur = sel
			m.refreshTranscript()
		}
	case "history":
		// открыть сохранённый чат в новой вкладке
		idx := m.addSession(m.workdir)
		s := m.sessions[idx]
		s.name = item
		loadNamedSession(s.agent, item)
		m.cur = idx
		m.refreshTranscript()
		m.addToast("ok", "чат загружен: "+item)
	}
	return m, cmd
}

// ---------- слэш-команды (стиль opencode; hermes-алиасы в скобках) ----------
func (m *tuiModel) dispatchCommand(line string) tea.Cmd {
	fields := strings.Fields(line)
	if len(fields) == 0 {
		return nil
	}
	cmd := fields[0]
	if n, err := strconvAtoi(cmd); err == nil {
		if n >= 1 && n <= len(m.sessions) {
			m.cur = n - 1
			m.refreshTranscript()
		}
		return nil
	}
	switch cmd {
	case "/history":
		names := listSavedSessions()
		if len(names) == 0 {
			m.addToast("info", "сохранённых чатов нет")
		} else {
			m.openPicker("history", "История чатов", names)
		}
	case "/lang":
		if uiLang == "ru" {
			setUILang("en")
		} else {
			setUILang("ru")
		}
		m.saveSettings()
		m.addToast("ok", T("toast.lang")+uiLang)
	case "/attach", "/image", "/img":
		if len(fields) < 2 {
			m.addToast("err", "использование: /attach <путь к картинке> [ещё пути]")
			break
		}
		if !modelSupportsVision(m.model) {
			m.addToast("err", "модель "+shortModel(m.model)+" не vision — картинки не уйдут. Смени: /model")
			break
		}
		s := m.sessions[m.cur]
		ok := 0
		for _, p := range fields[1:] {
			du, err := imageToDataURL(p)
			if err != nil {
				m.addToast("err", p+": "+err.Error())
				continue
			}
			s.agent.pendingImages = append(s.agent.pendingImages, du)
			ok++
		}
		if ok > 0 {
			m.addToast("ok", fmt.Sprintf("📎 прикреплено: %d изобр. — уйдут со следующим сообщением", ok))
		}
	case "/detach":
		s := m.sessions[m.cur]
		s.agent.pendingImages = nil
		m.addToast("ok", "прикрепления сняты")
	case "/help", "/?":
		m.openPicker("help", "Команды GOMNI", helpCommands)
	case "/models":
		if len(fields) > 1 && fields[1] == "refresh" {
			return m.fetchCmd()
		}
		if len(m.models) == 0 {
			return m.fetchCmd()
		}
		m.openPicker("models", "Модели — "+m.provider, m.models)
	case "/providers":
		var names []string
		for _, p := range providerDefs {
			names = append(names, p.Name)
		}
		names = append(names, "＋ свой провайдер (custom)")
		m.openPicker("provider", "Провайдеры", names)
	case "/provider":
		if len(fields) > 1 {
			name := strings.Join(fields[1:], " ")
			if !m.switchProvider(name) {
				m.addToast("err", "провайдер не найден")
			} else {
				m.addToast("ok", "провайдер: "+name)
				return m.fetchCmd()
			}
		} else {
			var names []string
			for _, p := range providerDefs {
				names = append(names, p.Name)
			}
			names = append(names, "＋ свой провайдер (custom)")
			m.openPicker("provider", "Провайдер", names)
		}
	case "/steer":
		if len(fields) > 1 {
			s := m.sessions[m.cur]
			txt := strings.Join(fields[1:], " ")
			if s.running {
				select {
				case s.agent.Steer <- txt:
					m.addToast("info", "steer: "+trunc(txt, 60))
				default:
					m.addToast("err", "очередь steer переполнена")
				}
			} else {
				m.addToast("err", "агент не запущен — steer ни к чему не применить")
			}
		}
	case "/queue":
		s := m.sessions[m.cur]
		s.mu.Lock()
		q := append([]string{}, s.queue...)
		s.mu.Unlock()
		if len(q) == 0 {
			m.addToast("info", "очередь пуста")
		} else {
			m.openPicker("queue", fmt.Sprintf("Очередь сообщений (%d)", len(q)), q)
		}
	case "/new":
		m.addSession(m.workdir)
		m.cur = len(m.sessions) - 1
		m.refreshTranscript()
	case "/chat":
		if len(fields) > 1 {
			switch fields[1] {
			case "new":
				m.addSession(m.workdir)
				m.cur = len(m.sessions) - 1
			case "next":
				m.cur = (m.cur + 1) % len(m.sessions)
			case "prev":
				m.cur = (m.cur - 1 + len(m.sessions)) % len(m.sessions)
			case "close":
				m.closeCurrent()
			}
			m.refreshTranscript()
		} else {
			var names []string
			for _, s := range m.sessions {
				names = append(names, s.name+" — "+s.workdir)
			}
			m.openPicker("chat", "Чаты", names)
		}
	case "/sessions":
		m.sidebar = !m.sidebar
		m.layout()
	case "/reset", "/wipe":
		m.sessions[m.cur].agent.Reset()
		os.Remove(filepath.Join(sessionsDir(), m.sessions[m.cur].name+".json"))
		m.addToast("ok", "контекст чата очищен")
	case "/compact":
		s := m.sessions[m.cur]
		sid := m.cur
		return func() tea.Msg {
			msg, err := s.agent.compactContext(context.Background())
			if err != nil {
				return chatDeltaMsg{sid: sid, kind: "err", text: err.Error()}
			}
			saveNamedSession(s.agent, s.name)
			return chatDeltaMsg{sid: sid, kind: "info", text: "сжатие: " + msg}
		}
	case "/memory":
		data, err := os.ReadFile(filepath.Join(workspaceDir(m.workdir), "..", ".gomni_memory.md"))
		if err != nil {
			m.addToast("info", "память пуста")
		} else {
			m.openPicker("help", "Память", strings.Split(clampStr(string(data), 2000), "\n"))
		}
	case "/plugins":
		var names []string
		for _, p := range m.plugins {
			names = append(names, fmt.Sprintf("%s v%s (%d тулов)", p.Name, p.Version, len(p.Tools)))
		}
		if len(names) == 0 {
			m.addToast("info", "плагинов нет")
		} else {
			m.openPicker("help", "Плагины", names)
		}
	case "/sandbox":
		if len(fields) > 1 && (fields[1] == "on" || fields[1] == "off") {
			os.Setenv("GOMNI_SANDBOX", fields[1])
			m.addToast("ok", "сандбокс: "+fields[1]+" (для новых агентов)")
		} else {
			m.addToast("info", fmt.Sprintf("сандбокс: %s", map[bool]string{true: "on", false: "off"}[sandboxEnabled()]))
		}
	case "/workdir":
		if len(fields) > 1 {
			s := m.sessions[m.cur]
			s.workdir = fields[1]
			s.mu.Lock()
			s.lines = append(s.lines, tline{"info", "рабочая папка: " + fields[1]})
			s.mu.Unlock()
			m.addToast("ok", "workdir: "+fields[1])
		}
	case "/notify":
		text := strings.TrimSpace(strings.TrimPrefix(line, "/notify"))
		notifySystem("SYNERGY", text)
		m.addToast("ok", "уведомление отправлено")
	case "/notify-cmd":
		if len(fields) > 1 {
			os.Setenv("GOMNI_NOTIFY_CMD", strings.TrimSpace(strings.TrimPrefix(line, "/notify-cmd")))
			m.addToast("ok", "notify-cmd обновлена")
		} else {
			m.addToast("info", "GOMNI_NOTIFY_CMD="+os.Getenv("GOMNI_NOTIFY_CMD"))
		}
	case "/stats":
		s := m.sessions[m.cur]
		m.addToast("info", fmt.Sprintf("чат %s: %d сообщений, ~%d KB, %d токенов", s.name, len(s.agent.Messages), s.agent.contextSize()/1024, s.agent.TotalTok))
	case "/quit", "/exit":
		return tea.Quit
	default:
		m.addToast("err", "неизвестная команда "+cmd+" — /help")
	}
	return nil
}

func strconvAtoi(s string) (int, error) {
	n := 0
	if s == "" {
		return 0, fmt.Errorf("empty")
	}
	for _, r := range s {
		if r < '0' || r > '9' {
			return 0, fmt.Errorf("bad")
		}
		n = n*10 + int(r-'0')
	}
	return n, nil
}

var helpCommands = []string{
	"/help                 справка",
	"/models [refresh]     выбор модели провайдера",
	"/provider [имя]       провайдер: zen-free | zen | openrouter",
	"/new                  новый чат",
	"/chat <new|next|prev|close>   управление чатами",
	"/sessions             панель чатов вкл/выкл",
	"/compact              сжать контекст (сабагент)",
	"/reset                очистить контекст чата",
	"/memory               память агента",
	"/plugins              плагины",
	"/sandbox <on|off>     сандбокс",
	"/workdir <путь>       рабочая папка чата",
	"/notify <текст>       кастомное уведомление ({msg})",
	"/stats                статистика",
	"/1..9                 переключить чат по номеру",
	"/quit                 выход",
}
